﻿/**
 * @file TestarCliente.cs
 * @brief Testes para as operações dos clientes (inserir e remover).
 * @author Paulo Silva
 * @date 2025-12-15
 * @version 2.0
 */

using Microsoft.VisualStudio.TestTools.UnitTesting;
using Fase2;

namespace Fase2
{
    /// <summary>
    /// Testes sobre os clientes.
    /// </summary>
    [TestClass]
    public class TestarCliente
    {
        #region Inserir Cliente
        /// <summary>
        /// Testa a operação de inserir um cliente.
        /// </summary>
        [TestMethod]
        public void InserirCliente()
        {
            // Arrange
            Cliente c1 = new Cliente("Paulo Silva", 123456789, "91223", "paulo@gmail.com");

            // Act
            bool resultado = RegrasClientes.TentarAdicionarCliente(c1);

            // Assert
            Assert.IsTrue(resultado, "Falhou.");
        }
        #endregion

        #region Remover Cliente
        /// <summary>
        /// Testa a operação de remover um cliente.
        /// </summary>
        [TestMethod]
        public void RemoverCliente()
        {
            // Arrange
            Cliente c1 = new Cliente("Paulo Silva", 987654321, "912345679", "paulo@gmail.com");
            RegrasClientes.TentarAdicionarCliente(c1);

            // Act
            bool resultado = RegrasClientes.TentarRemoverCliente(987654321);

            // Assert
            Assert.IsTrue(resultado, "Falhou.");
        }
        #endregion
    }
}