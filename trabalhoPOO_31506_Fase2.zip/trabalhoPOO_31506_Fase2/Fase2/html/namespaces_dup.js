var namespaces_dup =
[
    [ "Fase2", "namespace_fase2.html", "namespace_fase2" ]
];