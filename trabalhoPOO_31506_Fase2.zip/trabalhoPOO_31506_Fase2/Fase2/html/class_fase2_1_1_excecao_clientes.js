var class_fase2_1_1_excecao_clientes =
[
    [ "ExcecaoClientes", "class_fase2_1_1_excecao_clientes.html#af6367e5029260a5dd852d2aaacb42694", null ],
    [ "CodigoErro", "class_fase2_1_1_excecao_clientes.html#af6559fa0080bbf15dc4fb46caa9ffe82", null ]
];