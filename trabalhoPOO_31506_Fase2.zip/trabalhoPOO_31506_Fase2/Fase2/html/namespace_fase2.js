var namespace_fase2 =
[
    [ "Alojamento", "class_fase2_1_1_alojamento.html", "class_fase2_1_1_alojamento" ],
    [ "Cliente", "class_fase2_1_1_cliente.html", "class_fase2_1_1_cliente" ],
    [ "Clientes", "class_fase2_1_1_clientes.html", null ],
    [ "ClientesExcecoes", "class_fase2_1_1_clientes_excecoes.html", "class_fase2_1_1_clientes_excecoes" ],
    [ "Pessoa", "class_fase2_1_1_pessoa.html", "class_fase2_1_1_pessoa" ],
    [ "RegrasClientes", "class_fase2_1_1_regras_clientes.html", null ],
    [ "Reserva", "class_fase2_1_1_reserva.html", "class_fase2_1_1_reserva" ],
    [ "Responsavel", "class_fase2_1_1_responsavel.html", "class_fase2_1_1_responsavel" ],
    [ "TestarCliente", "class_fase2_1_1_testar_cliente.html", "class_fase2_1_1_testar_cliente" ],
    [ "EstadoReserva", "namespace_fase2.html#a289c380b67fdd0c93675fc44b82b54cd", [
      [ "Pendente", "namespace_fase2.html#a289c380b67fdd0c93675fc44b82b54cdaec51ded1eadec8cf7f8521794fe22deb", null ],
      [ "Confirmada", "namespace_fase2.html#a289c380b67fdd0c93675fc44b82b54cda1a10ff380e07f18a9d770248437ac6db", null ],
      [ "Concluida", "namespace_fase2.html#a289c380b67fdd0c93675fc44b82b54cda8fa47b56a022772b00f8ba7d853024b4", null ],
      [ "Cancelada", "namespace_fase2.html#a289c380b67fdd0c93675fc44b82b54cdaaee1bd2bf7955aa463ef39de428f0d2c", null ]
    ] ]
];