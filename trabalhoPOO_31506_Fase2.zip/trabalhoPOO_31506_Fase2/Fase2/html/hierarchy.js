var hierarchy =
[
    [ "Fase2.Alojamento", "class_fase2_1_1_alojamento.html", null ],
    [ "Fase2.Clientes", "class_fase2_1_1_clientes.html", null ],
    [ "Exception", null, [
      [ "Fase2.ClientesExcecoes", "class_fase2_1_1_clientes_excecoes.html", null ]
    ] ],
    [ "IComparable", null, [
      [ "Fase2.Cliente", "class_fase2_1_1_cliente.html", null ]
    ] ],
    [ "Fase2.Pessoa", "class_fase2_1_1_pessoa.html", [
      [ "Fase2.Cliente", "class_fase2_1_1_cliente.html", null ],
      [ "Fase2.Responsavel", "class_fase2_1_1_responsavel.html", null ]
    ] ],
    [ "Program", "class_program.html", null ],
    [ "Fase2.RegrasClientes", "class_fase2_1_1_regras_clientes.html", null ],
    [ "Fase2.Reserva", "class_fase2_1_1_reserva.html", null ],
    [ "Fase2.TestarCliente", "class_fase2_1_1_testar_cliente.html", null ]
];