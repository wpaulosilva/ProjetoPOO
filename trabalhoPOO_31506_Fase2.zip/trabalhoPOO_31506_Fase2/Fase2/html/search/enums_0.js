var searchData=
[
  ['estadoreserva_0',['EstadoReserva',['../namespace_fase2.html#a289c380b67fdd0c93675fc44b82b54cd',1,'Fase2']]]
];
