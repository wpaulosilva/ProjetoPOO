var searchData=
[
  ['nif_0',['Nif',['../class_fase2_1_1_pessoa.html#a006b231e3d51964b709724f2f567f1da',1,'Fase2::Pessoa']]],
  ['nome_1',['Nome',['../class_fase2_1_1_pessoa.html#a75b7d4efcf4a7f6b7f52483cfc9ceb49',1,'Fase2::Pessoa']]]
];
