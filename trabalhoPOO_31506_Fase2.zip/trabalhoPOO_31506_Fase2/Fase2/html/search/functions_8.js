var searchData=
[
  ['tentaradicionarcliente_0',['TentarAdicionarCliente',['../class_fase2_1_1_regras_clientes.html#a58d210fa0e859495f5d982cb753e915a',1,'Fase2::RegrasClientes']]],
  ['tentarguardar_1',['TentarGuardar',['../class_fase2_1_1_regras_clientes.html#a0ed52d1fac01478c76295cb6826d74f7',1,'Fase2::RegrasClientes']]],
  ['tentarler_2',['TentarLer',['../class_fase2_1_1_regras_clientes.html#aad8fb75b22cdc6653e6d070e8c41fca3',1,'Fase2::RegrasClientes']]],
  ['tentarremovercliente_3',['TentarRemoverCliente',['../class_fase2_1_1_regras_clientes.html#ab3a71170d1659dc2489e7fb2b844317a',1,'Fase2::RegrasClientes']]]
];
