var searchData=
[
  ['gestão_20de_20alojamentos_20turísticos_0',['Gestão de Alojamentos Turísticos',['../index.html',1,'']]],
  ['guardarclientes_1',['GuardarClientes',['../class_fase2_1_1_clientes.html#aa01bbee6a34949e820b509c9b4a581d5',1,'Fase2::Clientes']]]
];
