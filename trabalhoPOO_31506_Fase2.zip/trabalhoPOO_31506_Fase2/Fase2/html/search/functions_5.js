var searchData=
[
  ['pessoa_0',['Pessoa',['../class_fase2_1_1_pessoa.html#a32162e3028849fa7e8d7024bc9bb1655',1,'Fase2.Pessoa.Pessoa()'],['../class_fase2_1_1_pessoa.html#a1670b61ede91a873728cfe186be9ba79',1,'Fase2.Pessoa.Pessoa(string n, int i, string t)']]],
  ['procurarcliente_1',['ProcurarCliente',['../class_fase2_1_1_clientes.html#a54102a507e022a1c0ea62398d94018fd',1,'Fase2::Clientes']]]
];
