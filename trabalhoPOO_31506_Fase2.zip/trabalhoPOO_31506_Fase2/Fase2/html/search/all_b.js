var searchData=
[
  ['quantidadepessoas_0',['QuantidadePessoas',['../class_fase2_1_1_reserva.html#a24e2404964d8ccacdcd1c771eb7e53c1',1,'Fase2::Reserva']]]
];
