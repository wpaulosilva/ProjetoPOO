var searchData=
[
  ['obterclientes_0',['ObterClientes',['../class_fase2_1_1_clientes.html#a555e867befff02f5a150c20543a5f83e',1,'Fase2::Clientes']]],
  ['ordenarcliente_1',['OrdenarCliente',['../class_fase2_1_1_regras_clientes.html#a12021ae282f157a8f73df8710dcefa96',1,'Fase2::RegrasClientes']]]
];
