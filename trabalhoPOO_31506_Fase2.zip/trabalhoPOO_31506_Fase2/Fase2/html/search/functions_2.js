var searchData=
[
  ['guardarclientes_0',['GuardarClientes',['../class_fase2_1_1_clientes.html#aa01bbee6a34949e820b509c9b4a581d5',1,'Fase2::Clientes']]]
];
