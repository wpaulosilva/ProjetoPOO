var class_fase2_1_1_cliente =
[
    [ "Cliente", "class_fase2_1_1_cliente.html#a9c782ea22528eb3a4165f16de3f74561", null ],
    [ "CompareTo", "class_fase2_1_1_cliente.html#afb53c323fba7eff3dda10d349696ac35", null ],
    [ "Email", "class_fase2_1_1_cliente.html#a1564587e55e655141ee817d226a860f3", null ]
];