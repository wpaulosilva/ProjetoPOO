var class_fase2_1_1_testar_cliente =
[
    [ "InserirCliente", "class_fase2_1_1_testar_cliente.html#a82780766d20a7cc42893a830e691e351", null ],
    [ "RemoverCliente", "class_fase2_1_1_testar_cliente.html#aba6a3032ed1f9f032b1b85d4b3c4cbe2", null ]
];