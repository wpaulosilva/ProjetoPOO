var dir_a9c881126609c30d96576a58354b982d =
[
    [ "RegrasCliente.cs", "_regras_cliente_8cs.html", "_regras_cliente_8cs" ]
];