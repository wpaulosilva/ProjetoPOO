var class_fase2_1_1_reserva =
[
    [ "Reserva", "class_fase2_1_1_reserva.html#a9331f9f096e3810acb8ce9f1c65d09e1", null ],
    [ "CheckInEfetuado", "class_fase2_1_1_reserva.html#af8315514649ace7534b7f3d0e97bd4ed", null ],
    [ "DataCheckIn", "class_fase2_1_1_reserva.html#a6654f31d5cad4c8847112c600eae806d", null ],
    [ "DataCheckOut", "class_fase2_1_1_reserva.html#a1ec7f775f80353424e3dd0189ac9c7d3", null ],
    [ "Estado", "class_fase2_1_1_reserva.html#a054e5d1658f05b9aa770e9ab3a1cdd73", null ],
    [ "Id", "class_fase2_1_1_reserva.html#a040589283ae49b672c6886038510afd4", null ],
    [ "IdAlojamento", "class_fase2_1_1_reserva.html#af2b15e0f8f73b8970c4acc84404a92da", null ],
    [ "IdCliente", "class_fase2_1_1_reserva.html#a461fc64d432fdb16208cdb776bea7c3e", null ],
    [ "PrecoNoMomento", "class_fase2_1_1_reserva.html#a1be9083a31478b756c068c2e6d53af13", null ],
    [ "PrecoTotal", "class_fase2_1_1_reserva.html#ac641a348bde63a30a8f003f0cc4068f3", null ],
    [ "QuantidadePessoas", "class_fase2_1_1_reserva.html#a24e2404964d8ccacdcd1c771eb7e53c1", null ]
];