var class_fase2_1_1_pessoa =
[
    [ "Pessoa", "class_fase2_1_1_pessoa.html#a32162e3028849fa7e8d7024bc9bb1655", null ],
    [ "Pessoa", "class_fase2_1_1_pessoa.html#a1670b61ede91a873728cfe186be9ba79", null ],
    [ "Nif", "class_fase2_1_1_pessoa.html#a006b231e3d51964b709724f2f567f1da", null ],
    [ "Nome", "class_fase2_1_1_pessoa.html#a75b7d4efcf4a7f6b7f52483cfc9ceb49", null ],
    [ "Telefone", "class_fase2_1_1_pessoa.html#a90f7ca85a4c9cde76345abc9fb9a2b05", null ]
];