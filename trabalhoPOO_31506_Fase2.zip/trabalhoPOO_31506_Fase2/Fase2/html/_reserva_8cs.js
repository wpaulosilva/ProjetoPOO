var _reserva_8cs =
[
    [ "Fase2.Reserva", "class_fase2_1_1_reserva.html", "class_fase2_1_1_reserva" ],
    [ "Fase2.EstadoReserva", "namespace_fase2.html#a289c380b67fdd0c93675fc44b82b54cd", [
      [ "Fase2.EstadoReserva.Pendente", "namespace_fase2.html#a289c380b67fdd0c93675fc44b82b54cdaec51ded1eadec8cf7f8521794fe22deb", null ],
      [ "Fase2.EstadoReserva.Confirmada", "namespace_fase2.html#a289c380b67fdd0c93675fc44b82b54cda1a10ff380e07f18a9d770248437ac6db", null ],
      [ "Fase2.EstadoReserva.Concluida", "namespace_fase2.html#a289c380b67fdd0c93675fc44b82b54cda8fa47b56a022772b00f8ba7d853024b4", null ],
      [ "Fase2.EstadoReserva.Cancelada", "namespace_fase2.html#a289c380b67fdd0c93675fc44b82b54cdaaee1bd2bf7955aa463ef39de428f0d2c", null ]
    ] ]
];