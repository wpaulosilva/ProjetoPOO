﻿/**
 * @file RegrasCliente.cs
 * @brief Classe para aplicar regras relativamento aos clientes.
 * @author Paulo Silva
 * @date 2025-12-15
 * @version 2.0
 */

using System;
using System.Collections.Generic;

namespace Fase2
{
    /// <summary>
    /// Classe que implementa regras para os clientes.
    /// </summary>
    public class RegrasClientes
    {
        #region Adicionar Cliente
        /// <summary>
        /// Tenta adicionar um cliente à aux, validando os dados fornecidos.
        /// </summary>
        public static bool TentarAdicionarCliente(Cliente c)
        {
            if (c.Nif < 100000000 || c.Nif > 999999999)
            {
                return false;
            }

            if (c.Telefone.Length != 9)
            {
                return false;
            }

            if (!c.Email.Contains("@"))
            {
                return false;
            }

            if (Clientes.ProcurarCliente(c.Nif) != null)
            {
                return false;
            }

            if (c == null)
            {
                return false;
            }

            //Cliente c = new Cliente(nome, nif, telefone, email);

            return Clientes.AdicionarCliente(c);
        }
        #endregion

        #region Remover Cliente
        /// <summary>
        /// Tenta remover um cliente com base no NIF.
        /// </summary>
        /// <param name="nif">NIFdo cliente a remover.</param>
        /// <returns>
        /// Retorna <c>true</c> se o cliente foi removido com sucesso,
        /// ou <c>false</c> se não existir ou se ocorrer erro.
        /// </returns>
        public static bool TentarRemoverCliente(int nif)
        {
            if (nif < 100000000 || nif > 999999999)
            {
                return false;
            }
            return Clientes.RemoverCliente(nif);
        }
        #endregion

        #region Guardar clientes
        /// <summary>
        /// Tenta guardar os clientes no ficheiro binário.
        /// </summary>
        public static bool TentarGuardar(string ficheiro)
        {
            try
            {
                return Clientes.GuardarClientes(ficheiro);
            }
            catch (ClientesExcecoes)
            {
                return false;
            }
            catch (Exception)
            {
                return false;
            }
        }
        #endregion

        #region Ler Clientes
        /// <summary>
        /// Tenta ler os clientes do ficheiro binário.
        /// </summary>
        public static bool TentarLer(string ficheiro)
        {
            try
            {
                return Clientes.CarregaClientes(ficheiro);
            }
            catch (ClientesExcecoes)
            {
                return false;
            }
            catch (Exception)
            {
                return false;
            }
        }
        #endregion

        #region Ordenar Clientes
        /// <summary>
        /// Ordena a Lista de clientes pelo nome.
        /// </summary>
        public static List<Cliente> OrdenarCliente()
        {
            List<Cliente> aux = Clientes.ObterClientes();
            aux.Sort();
            return aux;
        }
        #endregion
    }
}
