﻿/**
 * @file Program.cs
 * @brief Programa executável.
 * @author Paulo Silva
 * @date 2025-12-15
 * @version 2.0
 */

using Fase2;
using System;

class Program
{
    /// <summary>
    /// Executar o programa.
    /// </summary>
    static void Main(string[] args)
    {
        #region Inserir Clientes

        Cliente c1 = new Cliente("Paulo Silva", 123456789, "912345678", "paulo@gmail.com");
        bool aux1 = RegrasClientes.TentarAdicionarCliente(c1);
        if (aux1)
        {
            Console.WriteLine("Inserido: " + c1.Nome);
        }
        else
        {
            Console.WriteLine("Erro.");
        }

        Cliente c2 = new Cliente("Manuel Silva", 987654321, "923456789", "manuel@gmail.com");
        bool aux2 = RegrasClientes.TentarAdicionarCliente(c2);
        if (aux2)
        {
            Console.WriteLine("Inserido: " + c2.Nome);
        }
        else
        {
            Console.WriteLine("Erro.");
        }
        #endregion

        #region Mostrar Clientes
        foreach (Cliente c in RegrasClientes.OrdenarCliente())
        {
            Console.WriteLine("Nome: " + c.Nome + ", NIF: " + c.Nif);
        }
        #endregion

        #region Ficheiros
        string ficheiro = "clientes.dat";

        bool guardar = RegrasClientes.TentarGuardar(ficheiro);
        if (guardar)
        {
            Console.WriteLine("Guardado");
        }
        else
        {
            Console.WriteLine("Erro");
        }

        bool ler = RegrasClientes.TentarLer(ficheiro);
        if (ler)
        {
            Console.WriteLine("Carregado");
        }
        else
        {
            Console.WriteLine("Erro");
        }
        #endregion
    }
}