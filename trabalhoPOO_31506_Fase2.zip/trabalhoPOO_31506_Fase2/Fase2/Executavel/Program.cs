﻿/**
 * @file Program.cs
 * @brief Programa executável.
 * @author Paulo Silva
 * @date 2025-12-15
 * @version 2.0
 */

using Fase2;
using System;
using System.Collections.Generic;

class Program
{
    /// <summary>
    /// Executar o programa.
    /// </summary>
    static void Main(string[] args)
    {  
        Cliente a1 = new Cliente("Paulo Silva", 173456789, "912345678", "paulo@gmail.com");
        bool inserido = RegrasClientes.TentarAdicionarCliente(a1);

        if (inserido)
            Console.WriteLine("Inserido: " + a1.Nome);
        else
            Console.WriteLine("Erro");

        Cliente a2 = new Cliente("Bruno Silva", 173456789, "923456789", "bruno@gmail.com");
        bool inserido2 = RegrasClientes.TentarAdicionarCliente(a2);
        if (inserido2)
            Console.WriteLine("Inserido: " + a2.Nome);
        else
            Console.WriteLine("Erro");

        //bool removido1 = RegrasClientes.TentarRemoverCliente(173456789);
        //if (removido1)
        //{
        //    Console.WriteLine("Removido");
        //}
        //else
        //{
        //    Console.WriteLine("Erro");
        //}

        foreach (Cliente c in RegrasClientes.OrdenarCliente())
        {
            Console.WriteLine("Nome: " + c.Nome + ", NIF: " + c.Nif);
        }

        string ficheiro = "clientes.dat";

        bool guardar = RegrasClientes.TentarGuardar(ficheiro);
        if (guardar)
        {
            Console.WriteLine("Guardado");
        }
        else
        {
            Console.WriteLine("Erro");
        }

        bool ler = RegrasClientes.TentarLer(ficheiro);
        if (ler)
        {
            Console.WriteLine("Carregado");
        }
        else
        {
            Console.WriteLine("Erro");
        }
    }
}