﻿/**
 * @file ExcecoesCliente.cs
 * @brief Exceções dos ficheiros dos clientes.
 * @author Paulo Silva
 * @date 2025-12-15
 * @version 2.0
 */

using System;

namespace Fase2
{
    /// <summary>
    /// Representa exceções relacionadas com ficheiros.
    /// </summary>
    public class ClientesExcecoes : Exception
    {
        /// <summary>
        /// Construtor padrão.
        /// </summary>
        public ClientesExcecoes() : base("Ficheiro inválido.") { }

        /// <summary>
        /// Construtor que recebe uma mensagem.
        /// </summary>
        /// <param name="msg">Mensagem da exceção.</param>
        public ClientesExcecoes(string msg) : base(msg) { }

        /// <summary>
        /// Construtor que recebe uma mensagem e uma exceção.
        /// </summary>
        /// <param name="msg">Mensagem da exceção.</param>
        /// <param name="e">Exceção que causou esta exceção.</param>
        public ClientesExcecoes(string msg, Exception e) : base(msg, e) { }
    }
}
