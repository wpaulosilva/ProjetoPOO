﻿/**
 * @file ExcecoesCliente.cs
 * @brief Exceções dos ficheiros dos clientes.
 * @author Paulo Silva
 * @date 2025-12-15
 * @version 2.0
 */

using System;

namespace Fase2
{
    /// <summary>
    /// Representa exceções relacionadas com ficheiros.
    /// </summary>
    public class ClientesExcecoes : Exception
    {
        /// <summary>
        /// Contrutor padrão.
        /// </summary>
        public ClientesExcecoes() : base("Ocorreu um erro.") { }

        /// <summary>
        /// Contrutor com mensagem.
        /// </summary>
        //public ClientesExcecoes(string s) : base(s) { }
    }
}
