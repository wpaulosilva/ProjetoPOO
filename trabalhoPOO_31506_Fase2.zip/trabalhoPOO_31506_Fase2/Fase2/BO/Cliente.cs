﻿/**
 * @file Cliente.cs
 * @brief Define a classe Cliente, que herda de Pessoa e adiciona o atributo email.
 * @author Paulo Silva
 * @date 2025-12-15
 * @version 2.0
 */

using System;

namespace Fase2
{
    /// <summary>
    /// Representa um cliente.
    /// </summary>
    [Serializable]
    public class Cliente : Pessoa, IComparable<Cliente>
    {
        #region Attributes
        /// <summary>
        /// Email do cliente.
        /// </summary>
        string email;
        #endregion

        #region Methods

        #region Constructors
        /// <summary>
        /// Construtor parametrizado.
        /// </summary>
        /// 
        public Cliente(string n, int ni, string t, string e) : base(n, ni, t)
        {
            email = e;
        }
        #endregion

        #region Properties

        /// <summary>
        /// Obter ou definir o email do cliente.
        /// </summary>
        public string Email
        {
            get { return email; }
            set { email = value; }
        }

        #endregion

        #region Overrides
        #endregion

        #region OtherMethods
        /// <summary>
        /// Compara dois clientes pelo nome.
        /// </summary>
        public int CompareTo(Cliente auxCliente)
        {
            return string.Compare(this.Nome, auxCliente.Nome, StringComparison.OrdinalIgnoreCase);
        }
        #endregion

        #region Destructor
        #endregion

        #endregion
    }
}
