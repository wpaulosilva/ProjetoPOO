﻿/**
 * @file Alojamento.cs
 * @brief Classe Alojamento que representa um aloajamento.
 * @author Paulo Silva
 * @date 2025-12-15
 * @version 2.0
 */

using System;

namespace Fase2
{
    /// <summary>
    /// Representa um alojamento turístico.
    /// </summary>
    public class Alojamento
    {
        #region Attributes

        /// <summary>
        /// Identificador do alojamento.
        /// </summary>  
        int idAlojamento;

        /// <summary>
        /// Capacidade do alojamento.
        /// </summary>
        int capacidade;

        /// <summary>
        /// Morada do alojamento.
        /// </summary>
        string morada;

        /// <summary>
        /// Se o alojamento está disponível.
        /// </summary>
        bool disponivel;

        /// <summary>
        /// Tipo de alojamento.
        /// </summary>
        string tipoAlojamento;

        /// <summary>
        /// Preço por noite do alojamento.
        /// </summary>
        double precoPorNoite;

        #endregion

        #region Methods

        #region Constructors

        /// <summary>
        /// Construtor parametrizado.
        /// </summary>
        public Alojamento(int i, int c, string m, bool d, string tip, double preco)
        {
            idAlojamento = i;
            capacidade = c;
            morada = m;
            disponivel = d;
            tipoAlojamento = tip;
            precoPorNoite = preco;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Obter ou definir o Id do alojamento.
        /// </summary>
        public int IdAlojamento
        {
            get { return idAlojamento; }
            set { idAlojamento = value; }
        }

        /// <summary>
        /// Obter ou definir o Preco por Noite do alojamento.
        /// </summary>
        public double PrecoPorNoite
        {
            get { return precoPorNoite; }
            set { precoPorNoite = value; }
        }

        /// <summary>
        /// Obter ou definir a capacidade do alojamento.
        /// </summary>
        public int Capacidade
        {
            get { return capacidade; }
            set { capacidade = value; }
        }

        /// <summary>
        /// Obter ou definir a morada do alojamento.
        /// </summary>
        public string Morada
        {
            get { return morada; }
            set { morada = value; }
        }

        /// <summary>
        /// Obter ou definir se o alojamento está disponível.
        /// </summary>
        public bool Disponivel
        {
            get { return disponivel; }
            set { disponivel = value; }
        }

        /// <summary>
        /// Obter ou definir o tipo de alojamento.
        /// </summary>
        public string TipoAlojamento
        {
            get { return tipoAlojamento; }
            set { tipoAlojamento = value; }
        }

        #endregion

        #region Overrides
        #endregion

        #region OtherMethods

        /// <summary>
        /// Cria um novo alojamento.
        /// </summary>
        public static Alojamento CriarAlojamento(int id, int capacidade, string morada, bool disponivel, string tipoAlojamento, double precoPorNoite)
        {
            return new Alojamento(id, capacidade, morada, disponivel, tipoAlojamento, precoPorNoite);
        }

        #endregion

        #region Destructor
        #endregion

        #endregion
    }
}