﻿/**
 * @file Reserva.cs
 * @brief Define a classe Reserva e o enum EstadoReserva para as reservas.
 * @author Paulo Silva
 * @date 2025-12-15
 * @version 2.0
 */

using System;

namespace Fase2
{
    #region Estados
    /// <summary>
    /// Estados possíveis de uma reserva.
    /// </summary>
    public enum EstadoReserva
    {
        Pendente = 0,
        Confirmada = 1,
        Concluida = 2,
        Cancelada = 3,
    }
    #endregion

    /// <summary>
    /// Representa uma reserva de um alojamento.
    /// </summary>
    public class Reserva
    {
        #region Attributes

        /// <summary>
        /// Identificador único da reserva.
        /// </summary>
        int idReserva;

        /// <summary>
        /// Identificador do alojamento associado à reserva.
        /// </summary>
        int idAlojamento;

        /// <summary>
        /// Nif do cliente que efetuou a reserva.
        /// </summary>
        int nif;

        /// <summary>
        /// Data de check-in.
        /// </summary>
        DateTime dataCheckIn;

        /// <summary>
        /// Data de check-out.
        /// </summary>
        DateTime dataCheckOut;

        /// <summary>
        /// Quantidade de pessoas na reserva.
        /// </summary>
        int quantidadePessoas;

        /// <summary>
        /// Preço por noite do alojamento.
        /// </summary>
        double precoNoite;

        /// <summary>
        /// Preço total calculado para a reserva.
        /// </summary>
        double precoTotal;

        /// <summary>
        /// Estado atual da reserva. Por defeito, é Pendente.
        /// </summary>
        EstadoReserva estado = EstadoReserva.Pendente;

        /// <summary>
        /// Indica se o check-in já foi efetuado.
        /// </summary>
        bool checkInEfetuado = false;

        #endregion

        #region Methods

        #region Constructors

        /// <summary>
        /// Construtor parametrizado.
        /// </summary>
        public Reserva(int idr, int idA, int idC, DateTime checkI, DateTime checkO, int qtdPessoas, double precoPorNoite)
        {
            idReserva = idr;
            idAlojamento = idA;
            nif = idC;
            dataCheckIn = checkI.Date;
            dataCheckOut = checkO.Date;
            quantidadePessoas = qtdPessoas;
            precoNoite = precoPorNoite;

            estado = EstadoReserva.Pendente;
        }
        #endregion

        #region Properties

        /// <summary>
        /// Obter ou definir o id da reserva.
        /// </summary>
        public int Id
        {
            get { return idReserva; }
            set { idReserva = value; }
        }

        /// <summary>
        /// Obter ou definir o id do alojamento.
        /// </summary>
        public int IdAlojamento
        {
            get { return idAlojamento; }
            set { idAlojamento = value; }
        }

        /// <summary>
        /// Obter ou definir o nif do cliente.
        /// </summary>
        public int IdCliente
        {
            get { return nif; }
            set { nif = value; }
        }

        /// <summary>
        /// Obter ou definir a data de check-in.
        /// </summary>
        public DateTime DataCheckIn
        {
            get { return dataCheckIn; }
            set { dataCheckIn = value; }
        }

        /// <summary>
        /// Obter ou definir a data de check-out.
        /// </summary>
        public DateTime DataCheckOut
        {
            get { return dataCheckOut; }
            set { dataCheckOut = value; }
        }

        /// <summary>
        /// Obter ou definir a quantidade de pessoas.
        /// </summary>
        public int QuantidadePessoas
        {
            get { return quantidadePessoas; }
            set { quantidadePessoas = value; }
        }

        /// <summary>
        /// Obter ou definir o preço por noite.
        /// </summary>
        public double PrecoNoMomento
        {
            get { return precoNoite; }
            set { precoNoite = value; }
        }

        /// <summary>
        /// Obter ou definir o preço total da reserva.
        /// </summary>
        public double PrecoTotal
        {
            get { return precoTotal; }
            set { precoTotal = value; }
        }

        /// <summary>
        /// Obter ou definir o estado atual da reserva.
        /// </summary>
        public EstadoReserva Estado
        {
            get { return estado; }
            set { estado = value; }
        }

        /// <summary>
        /// Obter ou definir se o check-in foi efetuado.
        /// </summary>
        public bool CheckInEfetuado
        {
            get { return checkInEfetuado; }
            set { checkInEfetuado = value; }
        }

        #endregion

        #region OtherMethods
        #endregion

        #region Overrides
        #endregion

        #region Destructor
        #endregion

        #endregion
    }
}
