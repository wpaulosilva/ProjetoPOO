﻿/**
 * @file Program.cs
 * @brief Programa executável.
 * @author Paulo Silva
 * @date 2025-12-15
 * @version 2.0
 */

using Fase2;
using System;
using System.Collections.Generic;

class Program
{
    /// <summary>
    /// Executar o programa.
    /// </summary>
    static void Main(string[] args)
    {
        Cliente c1 = Cliente.CriarCliente("Paulo Silva", 123456789, "912345678", "paulo@gmail.com");

        bool aux1 = RegrasClientes.TentarAdicionarCliente(c1);

        if (aux1)
        {
            Console.WriteLine("Inserido: " + c1.Nome);
        }
        else
        {
            Console.WriteLine("Erro.");
        }

        Cliente c2 = Cliente.CriarCliente("Manuel Silva", 987654321, "923456789", "joao@gmail.com");
        bool aux2 = RegrasClientes.TentarAdicionarCliente(c2);
        if (aux2)
        {
            Console.WriteLine("Inserido: " + c2.Nome);
        }
        else
        {
            Console.WriteLine("Erro.");
        }

        Cliente c3 = Cliente.CriarCliente("José Silva", 123, "934567890", "jose@gmail.com"); 
        bool aux3 = RegrasClientes.TentarAdicionarCliente(c3);
        if (aux3)
        {
            Console.WriteLine("Inserido: " + c3.Nome);
        }
        else
        {
            Console.WriteLine("Erro.");
        }

        //bool removido1 = RegrasClientes.TentarRemoverCliente(173456789);
        //if (removido1)
        //{
        //    Console.WriteLine("Removido");
        //}
        //else
        //{
        //    Console.WriteLine("Erro");
        //}

        int resultado = c3.CompareTo(c1);
        if (resultado < 0)
        {
            Console.WriteLine("C3 VEM ANTES DE C1");
        }
        else if (resultado > 0)
        {
            Console.WriteLine("C1 VEM ANTES DE C3");
        }
        else
        {
            Console.WriteLine("C1 E C3 SÃO IGUAIS");
        }

        foreach (Cliente c in RegrasClientes.OrdenarCliente())
        {
            Console.WriteLine("Nome: " + c.Nome + ", NIF: " + c.Nif);
        }

        string ficheiro = "clientes.dat";

        bool guardar = RegrasClientes.TentarGuardar(ficheiro);
        if (guardar)
        {
            Console.WriteLine("Guardado");
        }
        else
        {
            Console.WriteLine("Erro");
        }

        //bool ler = RegrasClientes.TentarLer(ficheiro);
        //if (ler)
        //{
        //    Console.WriteLine("Carregado");
        //}
        //else
        //{
        //    Console.WriteLine("Erro");
        //}
    }
}