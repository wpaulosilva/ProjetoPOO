var searchData=
[
  ['📚_20tecnologias_0',['📚 Tecnologias',['../index.html#autotoc_md8',1,'']]]
];
