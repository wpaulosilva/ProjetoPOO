var searchData=
[
  ['regrascliente_2ecs_0',['RegrasCliente.cs',['../_regras_cliente_8cs.html',1,'']]],
  ['regrasclientes_1',['RegrasClientes',['../class_fase2_1_1_regras_clientes.html',1,'Fase2']]],
  ['removercliente_2',['RemoverCliente',['../class_fase2_1_1_clientes.html#a97abd5c9a5fd5fb26a3ecec243a2c495',1,'Fase2.Clientes.RemoverCliente()'],['../class_fase2_1_1_testar_cliente.html#aba6a3032ed1f9f032b1b85d4b3c4cbe2',1,'Fase2.TestarCliente.RemoverCliente()']]],
  ['reserva_3',['Reserva',['../class_fase2_1_1_reserva.html',1,'Fase2.Reserva'],['../class_fase2_1_1_reserva.html#a9331f9f096e3810acb8ce9f1c65d09e1',1,'Fase2.Reserva.Reserva()']]],
  ['reserva_2ecs_4',['Reserva.cs',['../_reserva_8cs.html',1,'']]],
  ['responsavel_5',['Responsavel',['../class_fase2_1_1_responsavel.html',1,'Fase2.Responsavel'],['../class_fase2_1_1_responsavel.html#a1d34c32881f1099ea55a0cb09eca1610',1,'Fase2.Responsavel.Responsavel()']]],
  ['responsavel_2ecs_6',['Responsavel.cs',['../_responsavel_8cs.html',1,'']]]
];
