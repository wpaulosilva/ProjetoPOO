var searchData=
[
  ['tecnologias_0',['📚 Tecnologias',['../index.html#autotoc_md8',1,'']]],
  ['telefone_1',['Telefone',['../class_fase2_1_1_pessoa.html#a90f7ca85a4c9cde76345abc9fb9a2b05',1,'Fase2::Pessoa']]],
  ['tentaradicionarcliente_2',['TentarAdicionarCliente',['../class_fase2_1_1_regras_clientes.html#a2b71544317b5be54ed8d45e8640bc138',1,'Fase2::RegrasClientes']]],
  ['tentarguardar_3',['TentarGuardar',['../class_fase2_1_1_regras_clientes.html#a0ed52d1fac01478c76295cb6826d74f7',1,'Fase2::RegrasClientes']]],
  ['tentarler_4',['TentarLer',['../class_fase2_1_1_regras_clientes.html#aad8fb75b22cdc6653e6d070e8c41fca3',1,'Fase2::RegrasClientes']]],
  ['tentarremovercliente_5',['TentarRemoverCliente',['../class_fase2_1_1_regras_clientes.html#ab3a71170d1659dc2489e7fb2b844317a',1,'Fase2::RegrasClientes']]],
  ['testarcliente_6',['TestarCliente',['../class_fase2_1_1_testar_cliente.html',1,'Fase2']]],
  ['testarcliente_2ecs_7',['TestarCliente.cs',['../_testar_cliente_8cs.html',1,'']]],
  ['tipoalojamento_8',['TipoAlojamento',['../class_fase2_1_1_alojamento.html#a0b5b0b6f6346a3973461bf0eb88fff3c',1,'Fase2::Alojamento']]],
  ['turísticos_9',['Gestão de Alojamentos Turísticos',['../index.html',1,'']]],
  ['turno_10',['Turno',['../class_fase2_1_1_responsavel.html#a57877aa1414f54654331cf3afb944d42',1,'Fase2::Responsavel']]]
];
