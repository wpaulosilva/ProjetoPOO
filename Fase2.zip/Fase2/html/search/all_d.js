var searchData=
[
  ['strong_0',['👤 &lt;strong&gt;Autor&lt;/strong&gt;',['../index.html#autotoc_md9',1,'']]],
  ['strong_20autor_20strong_1',['👤 &lt;strong&gt;Autor&lt;/strong&gt;',['../index.html#autotoc_md9',1,'']]]
];
