var searchData=
[
  ['inserircliente_0',['InserirCliente',['../class_fase2_1_1_testar_cliente.html#a82780766d20a7cc42893a830e691e351',1,'Fase2::TestarCliente']]]
];
