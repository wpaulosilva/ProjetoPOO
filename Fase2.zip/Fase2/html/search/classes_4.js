var searchData=
[
  ['testarcliente_0',['TestarCliente',['../class_fase2_1_1_testar_cliente.html',1,'Fase2']]]
];
