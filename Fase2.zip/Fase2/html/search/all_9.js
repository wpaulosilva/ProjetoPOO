var searchData=
[
  ['objetivos_0',['🎯 Objetivos',['../index.html#autotoc_md4',1,'']]],
  ['obterclientes_1',['ObterClientes',['../class_fase2_1_1_clientes.html#a555e867befff02f5a150c20543a5f83e',1,'Fase2::Clientes']]],
  ['ordenarcliente_2',['OrdenarCliente',['../class_fase2_1_1_regras_clientes.html#a12021ae282f157a8f73df8710dcefa96',1,'Fase2::RegrasClientes']]]
];
