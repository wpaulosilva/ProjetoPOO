var searchData=
[
  ['🛠_20funcionalidades_20principais_0',['🛠 Funcionalidades Principais',['../index.html#autotoc_md6',1,'']]]
];
