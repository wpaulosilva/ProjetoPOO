var searchData=
[
  ['id_0',['Id',['../class_fase2_1_1_reserva.html#a040589283ae49b672c6886038510afd4',1,'Fase2::Reserva']]],
  ['idalojamento_1',['IdAlojamento',['../class_fase2_1_1_alojamento.html#aa3011f261d16469ec5d25d0cdf1fa99d',1,'Fase2.Alojamento.IdAlojamento'],['../class_fase2_1_1_reserva.html#af2b15e0f8f73b8970c4acc84404a92da',1,'Fase2.Reserva.IdAlojamento']]],
  ['idcliente_2',['IdCliente',['../class_fase2_1_1_reserva.html#a461fc64d432fdb16208cdb776bea7c3e',1,'Fase2::Reserva']]]
];
