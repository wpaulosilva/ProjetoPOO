var indexSectionsWithContent =
{
  0: "acdefgimnopqrst🎯👤📂📌📚",
  1: "acprt",
  2: "f",
  3: "aceprt",
  4: "acgioprt",
  5: "e",
  6: "cdeimnpqt",
  7: "adgt"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "enums",
  6: "properties",
  7: "pages"
};

var indexSectionLabels =
{
  0: "Tudo",
  1: "Classes",
  2: "Namespaces",
  3: "Ficheiros",
  4: "Funções",
  5: "Enumerações",
  6: "Propriedades",
  7: "Páginas"
};

