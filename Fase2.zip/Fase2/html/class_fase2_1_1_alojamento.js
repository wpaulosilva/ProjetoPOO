var class_fase2_1_1_alojamento =
[
    [ "Alojamento", "class_fase2_1_1_alojamento.html#abe9786b9ce9746c831e254e030ab9fa9", null ],
    [ "Capacidade", "class_fase2_1_1_alojamento.html#aec0ad5373fbee0d6db18e86164db3901", null ],
    [ "Disponivel", "class_fase2_1_1_alojamento.html#a89f077c12c0318a1657544cb3a51632a", null ],
    [ "IdAlojamento", "class_fase2_1_1_alojamento.html#aa3011f261d16469ec5d25d0cdf1fa99d", null ],
    [ "Morada", "class_fase2_1_1_alojamento.html#a3501a1fcb845bac363dc48e62c173bb7", null ],
    [ "PrecoPorNoite", "class_fase2_1_1_alojamento.html#af0995a3775c56740eeecaa8c7a87caf0", null ],
    [ "TipoAlojamento", "class_fase2_1_1_alojamento.html#a0b5b0b6f6346a3973461bf0eb88fff3c", null ]
];