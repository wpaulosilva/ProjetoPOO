var _regras_cliente_8cs =
[
    [ "Fase2.RegrasClientes", "class_fase2_1_1_regras_clientes.html", null ]
];