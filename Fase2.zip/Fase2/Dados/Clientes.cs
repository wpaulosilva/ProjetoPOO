﻿/**
 * @file Clientes.cs
 * @brief Guardar os clientes numa lista
 * @author Paulo Silva
 * @date 2025-12-15
 * @version 2.0
 */

using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace Fase2
{
    /// <summary>
    /// Classe que armazena os clientes.
    /// </summary>
    public class Clientes   
    {
        /// <summary>
        /// Lista para guardar clientes.
        /// </summary>
        static List<Cliente> listaClientes = new List<Cliente>();

        #region Adicionar Cliente

        /// <summary>
        /// Adicionar um cliente à lista.
        /// </summary>
        public static bool AdicionarCliente(Cliente c)
        {
            if (c == null)
            {
                return false;
            }
            listaClientes.Add(c);
            return true;
        }
        #endregion

        #region Procurar Cliente
        /// <summary>
        /// Procurar um cliente pelo NIF.
        /// </summary>
        public static Cliente ProcurarCliente(int nif)
        {
            foreach (Cliente c in listaClientes)
            {
                if (c.Nif == nif)
                    return c;
            }
            return null;
        }
        #endregion

        #region Remover Cliente
        /// <summary>
        /// Remove um cliente da lista com base no NIF.
        /// </summary>
        public static bool RemoverCliente(int nif)
        {
            Cliente c = ProcurarCliente(nif);
            if (c == null)
            {
                return false;
            }
            else
            {
                listaClientes.Remove(c);
                return true;
            }
        }
        #endregion

        #region Guardar em Ficheiros
        /// <summary>
        /// Guarda a lista de clientes num ficheiro binário.
        /// </summary>
        public static bool GuardarClientes(string ficheiro)
        {
            if (ficheiro == "" || ficheiro == null)
            {
                throw new ClientesExcecoes("ERRO"); 
            }

            Stream s = File.Open(ficheiro, FileMode.OpenOrCreate, FileAccess.ReadWrite);
            BinaryFormatter b = new BinaryFormatter();
            b.Serialize(s, listaClientes);
            s.Close();

            return true;
        }
        #endregion

        #region Ler do Ficheiro
        /// <summary>
        /// Lê a lista de clientes de um ficheiro binário.
        /// </summary>
        public static bool CarregaClientes(string ficheiro)
        {
            if (ficheiro == "" || ficheiro == null)
            {
                throw new ClientesExcecoes("ERRO"); 
            }

            Stream s = File.Open(ficheiro, FileMode.Open, FileAccess.Read);
            BinaryFormatter b = new BinaryFormatter();
            listaClientes = (List<Cliente>)b.Deserialize(s);
            s.Close();

            return true;
        }
        #endregion

        #region Obter Clientes
        /// <summary>
        /// Obter a lista de clientes.
        /// </summary>
        public static List<Cliente> ObterClientes()
        {
            return listaClientes;
        }
        #endregion
    }       
}
