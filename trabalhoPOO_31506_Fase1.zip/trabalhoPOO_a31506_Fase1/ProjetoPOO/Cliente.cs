﻿/**
 * @file Cliente.cs
 * @brief Define a classe Cliente, que herda de Pessoa e adiciona o atributo email.
 * @author Paulo Silva
 * @date 2025-11-11
 * @version 1.0
 */

using System;

namespace ProjetoPOO
{
    /// <summary>
    /// Representa um cliente que herda de Pessoa.
    /// </summary>
    public class Cliente: Pessoa
    {
        #region Attributes

        /// <summary>
        /// Email do cliente.
        /// </summary
        string email;
        #endregion

        #region Methods

        #region Constructors

        /// <summary>
        /// Construtor por defeito.
        /// </summary>
        public Cliente(): base()
        {
            email = "";
        }

        #endregion

        #region Properties

        /// <summary>
        /// Obter ou definir o email do cliente.
        /// </summary>
        public string Email
        {
            get { return email; }
            set { email = value; }
        }

        #endregion

        #region Overrides
        #endregion

        #region OtherMethods

        #endregion

        #region Destructor
        #endregion

        #endregion
    }
}
