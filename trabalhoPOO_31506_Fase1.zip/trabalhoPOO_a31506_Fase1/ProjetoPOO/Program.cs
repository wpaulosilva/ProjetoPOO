﻿/**
 * @file Program.cs
 * @brief Main do Projeto.
 * @author Paulo Silva
 * @date 2025-11-11
 * @version 1.0
 */

using ProjetoPOO;
using System;

namespace ProjetoPOO
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Pessoa p1 = new Pessoa("João Silva", 123456789, "912345678");
            Console.WriteLine(p1.Nome + p1.Nif + p1.Telefone);

            Cliente c1 = new Cliente();
            c1.Nome = "Maria Oliveira";
            c1.Nif = 987654321; 
            c1.Telefone = "987654321";
            c1.Email = "a@gmail.com";
            Console.WriteLine(c1.Nome + c1.Email + c1.Nif);

            //Alojamento a1 = new Alojamento(4, "Rua, 123", true);

            Alojamento a1 = new Alojamento();
            Reserva r1 = new Reserva();
            r1.DataInicio = new DateTime(2024, 12, 20);
            r1.DataFim = new DateTime(2024, 12, 27);
            r1.PrecoNoite = 75.0f;
            Console.WriteLine(r1.DataInicio + " " + r1.DataFim + " " + r1.PrecoNoite);

        }
    }
}
