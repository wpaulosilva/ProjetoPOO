﻿/**
 * @file Pessoa.cs
 * @brief Define a classe Pessoa, que representa uma pessoa com nome, NIF e telefone.
 * @author Paulo Silva
 * @date 2025-11-11
 * @version 1.0
 */

using System;

namespace ProjetoPOO
{
    /// <summary>
    /// Representa uma pessoa com nome, NIF e telefone.
    /// </summary>
    public class Pessoa
    {
        #region Attributes

        /// <summary>
        /// Nome da pessoa.
        /// </summary>
        string nome;

        /// <summary>
        /// Número de identificação fiscal da pessoa.
        /// </summary>
        int nif;

        /// <summary>
        /// Telefone da pessoa.
        /// </summary>
        string telefone;

        #endregion

        #region Methods

        #region Constructors

        /// <summary>
        /// Construtor por defeito.
        /// </summary>
        public Pessoa()
        {
            nome = "";
            nif = 0;
            telefone = "";
        }

        /// <summary>
        /// Construtor parametrizado.
        /// </summary>
        /// <param name="n">Nome da pessoa.</param>
        /// <param name="i">NIF da pessoa.</param>
        /// <param name="t">Telefone da pessoa.</param>
        public Pessoa(string n, int i, string t)
        {
            nome = n;
            nif = i;
            telefone = t;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Obter ou definir o nome da pessoa.
        /// </summary>
        public string Nome
        {
            get { return nome; }
            set { nome = value; }
        }

        /// <summary>
        /// Obter ou definir o NIF da pessoa.
        /// </summary>
        public int Nif
        {
            get { return nif; }
            set { nif = value; }
        }

        /// <summary>
        /// Obter ou definir o telefone da pessoa.
        /// </summary>
        public string Telefone
        {
            get { return telefone; }
            set { telefone = value; }
        }
        #endregion

        #region Overrides
        #endregion

        #region OtherMethods
        #endregion

        #region Destructor
        #endregion

#endregion
    }
}
