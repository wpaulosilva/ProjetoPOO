﻿/**
 * @file Cliente.cs
 * @brief Classe Responsavel que herda de Pessoa e adiciona os atributos cargo e turno.
 * @author Paulo Silva
 * @date 2025-11-11
 * @version 1.0
 */

using System;

namespace ProjetoPOO
{
    /// <summary>
    /// Representa um responsável pelo alojamento.
    /// </summary>
    public class Responsavel: Pessoa
    {
        #region Attributes

        /// <summary>
        /// Cargo do responsável.
        /// </summary>
        string cargo;

        /// <summary>
        /// Turno do responsável.
        /// </summary>
        string turno;
        #endregion

        #region Methods

        #region Constructors

        /// <summary>
        /// Construtor por defeito.
        /// </summary>
        public Responsavel(): base()
        {
            cargo = "";
            turno = "";
        }
        #endregion

        #region Properties

        /// <summary>
        /// Obter ou definir o cargo do responsável.
        /// </summary>
        public string Cargo
        {
            get { return cargo; }
            set { cargo = value; }
        }

        /// <summary>
        /// Obter ou definir o turno do responsável.
        /// </summary>
        public string Turno
        {
            get { return turno; }
            set { turno = value; }
        }
        #endregion

        #region Overrides
        #endregion

        #region OtherMethods
        #endregion

        #region Destructor
        #endregion

        #endregion
    }
}
