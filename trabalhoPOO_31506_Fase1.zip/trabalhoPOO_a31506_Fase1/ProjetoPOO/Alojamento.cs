﻿/**
 * @file Cliente.cs
 * @brief Classe Alojamento que representa um alojamento com capacidade, morada e disponibilidade.
 * @author Paulo Silva
 * @date 2025-11-11
 * @version 1.0
 */

using System;

namespace ProjetoPOO
{
    /// <summary>
    /// Representa um alojamento turístico.
    /// </summary>
    public class Alojamento
    {
        #region Attributes

        /// <summary>
        /// Capacidade do alojamento.
        /// </summary>
        int capacidade;

        /// <summary>
        /// Morada do alojamento.
        /// </summary>
        string morada;

        /// <summary>
        /// Se o alojamento está disponível.
        /// </summary>
        bool disponivel;
        #endregion

        #region Methods

        #region Constructors

        /// <summary>
        /// Construtor por defeito.
        /// </summary>
        public Alojamento()
        {
            capacidade = 0;
            morada = "";
            disponivel = true;
        }

        /// <summary>
        /// Construtor parametrizado.
        /// </summary>
        /// <param name="c">Capacidade do alojamento.</param>
        /// <param name="m">Morada do alojamento.</param>
        /// <param name="d">Disponibilidade do alojamento.</param>
        public Alojamento(int c, string m, bool d, bool p)
        {
            capacidade = c;
            morada = m;
            disponivel = d;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Obter ou definir a capacidade do alojamento.
        /// </summary>
        public int Capacidade
        {
            get { return capacidade; }
            set { capacidade = value; }
        }

        /// <summary>
        /// Obter ou definir a morada do alojamento.
        /// </summary>
        public string Morada
        {
            get { return morada; }
            set { morada = value; }
        }

        /// <summary>
        /// Obter ou definir se o alojamento está disponível.
        /// </summary>
        public bool Disponivel
        {
            get { return disponivel; }
            set { disponivel = value; }
        }

        #endregion

        #region Overrides
        #endregion

        #region OtherMethods
        #endregion

        #region Destructor
        #endregion

        #endregion
    }
}
