var files_dup =
[
    [ "Alojamento.cs", "_alojamento_8cs.html", "_alojamento_8cs" ],
    [ "Cliente.cs", "_cliente_8cs.html", "_cliente_8cs" ],
    [ "Pessoa.cs", "_pessoa_8cs.html", "_pessoa_8cs" ],
    [ "Program.cs", "_program_8cs.html", "_program_8cs" ],
    [ "Reserva.cs", "_reserva_8cs.html", "_reserva_8cs" ],
    [ "Responsavel.cs", "_responsavel_8cs.html", "_responsavel_8cs" ]
];