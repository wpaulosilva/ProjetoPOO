var class_projeto_p_o_o_1_1_pessoa =
[
    [ "Pessoa", "class_projeto_p_o_o_1_1_pessoa.html#a9b9ce9442c9df8cb95dc16ea8a89d989", null ],
    [ "Pessoa", "class_projeto_p_o_o_1_1_pessoa.html#a004ea25f10855231105c4a067883ce49", null ],
    [ "nif", "class_projeto_p_o_o_1_1_pessoa.html#aba180664bc3a4cb10904cd4aa234ed08", null ],
    [ "nome", "class_projeto_p_o_o_1_1_pessoa.html#a97ff4a6b8b09845ed36ee683c543bf95", null ],
    [ "telefone", "class_projeto_p_o_o_1_1_pessoa.html#a31fc3276b373a73864fb85b04eed57da", null ]
];