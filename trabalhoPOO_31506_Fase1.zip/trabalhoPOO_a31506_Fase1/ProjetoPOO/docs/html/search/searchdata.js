var indexSectionsWithContent =
{
  0: "acdemnprt",
  1: "acpr",
  2: "p",
  3: "acpr",
  4: "acmpr",
  5: "cdemnpt"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables"
};

var indexSectionLabels =
{
  0: "Tudo",
  1: "Classes",
  2: "Namespaces",
  3: "Ficheiros",
  4: "Funções",
  5: "Variáveis"
};

