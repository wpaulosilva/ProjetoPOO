var searchData=
[
  ['telefone_0',['telefone',['../class_projeto_p_o_o_1_1_pessoa.html#a31fc3276b373a73864fb85b04eed57da',1,'ProjetoPOO::Pessoa']]],
  ['turno_1',['turno',['../class_projeto_p_o_o_1_1_responsavel.html#aa8fd12c1a863f6bd1e8152ef9d9e9af5',1,'ProjetoPOO::Responsavel']]]
];
