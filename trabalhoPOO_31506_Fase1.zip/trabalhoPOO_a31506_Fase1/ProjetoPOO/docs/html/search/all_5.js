var searchData=
[
  ['nif_0',['nif',['../class_projeto_p_o_o_1_1_pessoa.html#aba180664bc3a4cb10904cd4aa234ed08',1,'ProjetoPOO::Pessoa']]],
  ['nome_1',['nome',['../class_projeto_p_o_o_1_1_pessoa.html#a97ff4a6b8b09845ed36ee683c543bf95',1,'ProjetoPOO::Pessoa']]]
];
