var searchData=
[
  ['pessoa_0',['Pessoa',['../class_projeto_p_o_o_1_1_pessoa.html#a9b9ce9442c9df8cb95dc16ea8a89d989',1,'ProjetoPOO::Pessoa::Pessoa()'],['../class_projeto_p_o_o_1_1_pessoa.html#a004ea25f10855231105c4a067883ce49',1,'ProjetoPOO::Pessoa::Pessoa(string n, int i, string t)']]]
];
