var hierarchy =
[
    [ "ProjetoPOO::Alojamento", "class_projeto_p_o_o_1_1_alojamento.html", null ],
    [ "ProjetoPOO::Pessoa", "class_projeto_p_o_o_1_1_pessoa.html", [
      [ "ProjetoPOO::Cliente", "class_projeto_p_o_o_1_1_cliente.html", null ],
      [ "ProjetoPOO::Responsavel", "class_projeto_p_o_o_1_1_responsavel.html", null ]
    ] ],
    [ "ProjetoPOO::Program", "class_projeto_p_o_o_1_1_program.html", null ],
    [ "ProjetoPOO::Reserva", "class_projeto_p_o_o_1_1_reserva.html", null ]
];