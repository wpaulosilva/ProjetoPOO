var class_projeto_p_o_o_1_1_responsavel =
[
    [ "Responsavel", "class_projeto_p_o_o_1_1_responsavel.html#ad67811226001233074e06ed7360dbb4c", null ],
    [ "cargo", "class_projeto_p_o_o_1_1_responsavel.html#a2c5d4375fbb109945147fce3158661f5", null ],
    [ "turno", "class_projeto_p_o_o_1_1_responsavel.html#aa8fd12c1a863f6bd1e8152ef9d9e9af5", null ]
];