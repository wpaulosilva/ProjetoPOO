﻿/**
 * @file Cliente.cs
 * @brief Classe Reserva que representa uma reserva com datas e preços.
 * @author Paulo Silva
 * @date 2025-11-11
 * @version 1.0
 */

using System;

namespace ProjetoPOO
{
    /// <summary>
    /// Representa uma reserva de alojamento.
    /// </summary>
    public class Reserva
    {
        #region Attributes

        /// <summary>
        /// Data de início da reserva.
        /// </summary>
        DateTime dataInicio;

        /// <summary>
        /// Data de fim da reserva.
        /// </summary>
        DateTime dataFim;

        /// <summary>
        /// Preço por noite.
        /// </summary>
        float precoNoite;

        /// <summary>
        /// Preço total da reserva.
        /// </summary>
        float precoTotal;

        /// <summary>
        /// Se o check-in foi realizado.
        /// </summary>
        bool checkin;

        #endregion

        #region Methods

        #region Constructors

        /// <summary>
        /// Construtor por defeito.
        /// </summary>
        public Reserva()
        {
            dataInicio = DateTime.MinValue;
            dataFim = DateTime.MinValue;
            precoNoite = 0.0f;
            precoTotal = 0.0f;
            checkin = false;
        }

        /// <summary>
        /// Construtor parametrizado.
        /// </summary>
        /// <param name="di">Data de início.</param>
        /// <param name="df">Data de fim.</param>
        /// <param name="pn">Preço por noite.</param>
        /// <param name="pt">Preço total.</param>
        public Reserva(DateTime di, DateTime df, float pn, float pt)
        {
            dataInicio = di;
            dataFim = df;
            precoNoite = pn;
            precoTotal = pt;
            checkin = false;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Obter ou definir a data de início da reserva.
        /// </summary>
        public DateTime DataInicio
        {
            get { return dataInicio; }
            set { dataInicio = value; }
        }

        /// <summary>
        /// Obter ou definir a data de fim da reserva.
        /// </summary>
        public DateTime DataFim
        {
            get { return dataFim; }
            set { dataFim = value; }
        }

        /// <summary>
        /// Obter ou definir a o preço por noite da reserva.
        /// </summary>
        public float PrecoNoite
        {
            get { return precoNoite; }
            set { precoNoite = value; }
        }

        /// <summary>
        /// Obter ou definir a o preço total da reserva.
        /// </summary>
        public float PrecoTotal
        {
            get { return precoTotal; }
            set { precoTotal = value; }
        }

        /// <summary>
        /// Obter ou definir se o check-in foi realizado.
        /// </summary>
        public bool Checkin
        {
            get { return checkin; }
            set { checkin = value; }
        }
        #endregion

        #region Overrides
        #endregion

        #region OtherMethods
        #endregion

        #region Destructor
        #endregion

        #endregion
    }
}
